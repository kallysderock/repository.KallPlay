import xbmcaddon
MainBase = 'https://goo.gl/gnz9QA'
addon = xbmcaddon.Addon('plugin.video.MegaBoxTV')
# Safekodi

This is the Kodi addon for Safekodi project. For more information, please visit here: (https://safekodi.com/).
